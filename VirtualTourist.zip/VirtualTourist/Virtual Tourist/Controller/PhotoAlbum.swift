//
//  PhotoAlbum.swift
//  Virtual Tourist
//
//  Created by Can Yıldırım on 9.10.23.
//

import UIKit
import CoreLocation
import MapKit
import CoreData
import SkeletonView

class PhotoAlbum : UIViewController, MKMapViewDelegate,SkeletonCollectionViewDataSource {
 
    
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var flowLayOut: UICollectionViewFlowLayout!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var newCollectionButton: UIButton!
    
    lazy var photos = pin?.toPhoto?.allObjects as! [Photo]

    var pin: Pin? {
        
        didSet {
        
            fetchData()

            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                
                self.photos = (self.pin?.toPhoto?.allObjects as! [Photo]).sorted(by: {$0.date?.compare($1.date!) == .orderedAscending})
                
                self.collectionView.stopSkeletonAnimation()
                self.collectionView.hideSkeleton()
                self.collectionView.reloadData()
                
            }
            
        }
        
    }
    
    var page: Int = 0
        
    var dataController: DataController {
        
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.dataController
        
    }

    override func viewDidLoad() {
        
        activityIndicator.hidesWhenStopped = true
        selectedCoordinate()
        collectionFlowlayout()

        if pin?.toPhoto?.count == 0 {
            self.activityIndicator.startAnimating()
            self.newCollectionButton.isEnabled = false
            newCollectionTapped()
        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        collectionView.isSkeletonable = true
        collectionView.showAnimatedGradientSkeleton(usingGradient: .init(baseColor: .belizeHole), animation: nil, transition: .crossDissolve(0.25))
        
    }
 
    @IBAction func backButtonTapped(_ sender: UIButton) {
        
        self.dismiss(animated: true)

    }
    
    @IBAction func newCollectionTapped() {
        
        if let photos = pin?.toPhoto?.allObjects as? [Photo] {
            deleteFetchedObjects(objects: photos)
        }
                
        photos.removeAll()
        page += 1
        getData()

        
    }
    
    func selectedCoordinate() {
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: pin!.latitude, longitude: pin!.longitude)
        updatingTheMap(coordinate: annotation.coordinate, fromDistance: 100000, mapView: mapView)
        mapView.addAnnotation(annotation)
        collectionView.reloadData()
        
    }
    
    func collectionFlowlayout() {
        
        let space : CGFloat = 2.0
        let width = (view.frame.size.width - (2 * space)) / 3.0
        let height = (view.frame.size.height - (2 * space)) / 6.0
        flowLayOut.minimumInteritemSpacing = space
        flowLayOut.minimumLineSpacing = space
        flowLayOut.itemSize = CGSize(width: width, height: height)
        
    }
    
    func deleteFetchedObjects(objects: [NSManagedObject]) {
        
        for object in objects {
            dataController.viewContext.delete(object)
        }
        
        try? dataController.viewContext.save()
        
    }
    
    func fetchData() {
        
        let fetchedRequest: NSFetchRequest<Photo> = Photo.fetchRequest()
     
        let predicate = NSPredicate(format: "toPin.latitude == %f AND toPin.longitude == %f", pin!.latitude, pin!.longitude)
        fetchedRequest.predicate = predicate
 
        do {
            
            photos = try dataController.viewContext.fetch(fetchedRequest)

        } catch {
           
            fatalError("The fetch could not be performed: \(error.localizedDescription)")

        }
      
    }
    
    func getData() {

        VTClient.photosForLocation(latitude: pin!.latitude, longitude: pin!.longitude, page: self.page) { data, error in
            
            if data.count == 0 {
                                
                let alert = UIAlertController(title: "", message: "IMAGE NOT FOUND", preferredStyle: .actionSheet)
                
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    
                    alert.dismiss(animated: true)

                }
                     
                self.present(alert, animated: true)
                
            }
            
            self.activityIndicator.stopAnimating()
            self.newCollectionButton.isEnabled = true
            
            self.pin?.toPhoto = []

            for download in data {

                VTClient.download(server: download.server, id: download.id, secret: download.secret) { data, error in
                
                    guard data != nil else {return}

                        let savedPhoto = Photo(context: self.dataController.viewContext)
                        savedPhoto.photos = data
                        savedPhoto.date = Date()
                        savedPhoto.toPin = self.pin
                        self.photos.append(savedPhoto)
                        self.collectionView.reloadData()
                        try? self.dataController.viewContext.save()
                }

            }

        }

    }
    
}

extension PhotoAlbum: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
                
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionViewCell", for: indexPath) as! CollectionViewCell
        
        let image = photos[indexPath.row].photos
                
        if let image = image {
            
            cell.imageView.image = UIImage(data: image)
            
        }
    
        return cell
        
    }
    
    func collectionSkeletonView(_ skeletonView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 15
    }
    
    func collectionSkeletonView(_ skeletonView: UICollectionView, cellIdentifierForItemAt indexPath: IndexPath) -> SkeletonView.ReusableCellIdentifier {
        return "collectionViewCell"
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let allObjects = (pin?.toPhoto?.allObjects as! [Photo]).sorted(by: {$0.date?.compare($1.date!) == .orderedAscending})
        
        photos.remove(at: indexPath.row)
        dataController.viewContext.delete(allObjects[indexPath.row])
        try? dataController.viewContext.save()
        collectionView.deleteItems(at: [indexPath])
        
    }

}


