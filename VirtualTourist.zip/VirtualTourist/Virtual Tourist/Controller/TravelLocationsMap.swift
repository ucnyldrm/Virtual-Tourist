//
//  TravelLocationsMap.swift
//  Virtual Tourist
//
//  Created by Can Yıldırım on 9.10.23.
//

import UIKit
import CoreData
import MapKit

class TravelLocationsMap: UIViewController {
    
    @IBOutlet weak var mapView: MKMapView!
    
    var pins: [Pin]! = []
    var annotation: MKAnnotation!
    
    var dataController: DataController! {
        
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return  appDelegate.dataController
        
    }
    
    override func viewDidLoad() {

        if let annotations = getData() {
            
            updatingTheMap(coordinate: (annotations.last?.coordinate), fromDistance: 4000000, mapView: mapView)
            
            mapView.addAnnotations(annotations)
            
        }
        
    }
    
    @IBAction func addPin(_ sender: UILongPressGestureRecognizer) {
        
        if sender.state != . began {
            
            return
            
        }
        
        let location = sender.location(in: mapView)
        let coordinate = self.mapView.convert(location, toCoordinateFrom: self.mapView)
        
        let annotation = MKPointAnnotation()
        let savedCoordinate = Pin(context: dataController.viewContext)
        
        annotation.coordinate = CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude)

        savedCoordinate.latitude = annotation.coordinate.latitude
        savedCoordinate.longitude = annotation.coordinate.longitude
        try? dataController.viewContext.save()
        
        annotation.title = "Latitude: \(String(format: "%0.06f", annotation.coordinate.latitude))\nLongitude: \(String(format: "%0.06f", annotation.coordinate.longitude))"
 
        self.mapView.addAnnotation(annotation)
        
    }
    
    func getData() -> [MKAnnotation]? {

        do {
            pins = try dataController.viewContext.fetch(Pin.fetchRequest())

            var annotations = [MKAnnotation]()
            for pin in pins {
                let newAnnotation = MKPointAnnotation()
                newAnnotation.coordinate.latitude = pin.latitude
                newAnnotation.coordinate.longitude = pin.longitude
                newAnnotation.title = "Latitude: \(String(format: "%0.06f", pin.latitude))\nLongitude: \(String(format: "%0.06f", pin.longitude))"
                annotations.append(newAnnotation)
            }
        
            return annotations

        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }

    }

}

extension TravelLocationsMap: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, didSelect annotation: MKAnnotation) {
        
       self.annotation = annotation
        
       let fetchedRequest : NSFetchRequest<Pin> = Pin.fetchRequest()
       pins = try! dataController.viewContext.fetch(fetchedRequest)
      
       performSegue(withIdentifier: "toPhotoAlbum", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let photoAlbumVC = segue.destination as! PhotoAlbum
   
        photoAlbumVC.pin = pins.last(where: {$0.latitude == annotation.coordinate.latitude})
        
    }
        
}
