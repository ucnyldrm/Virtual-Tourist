//
//  CollectionViewCell.swift
//  Virtual Tourist
//
//  Created by Can Yıldırım on 13.10.23.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
}

