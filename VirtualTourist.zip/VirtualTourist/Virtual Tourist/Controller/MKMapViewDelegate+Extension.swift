//
//  MKMapViewDelegate+Extension.swift
//  Virtual Tourist
//
//  Created by Can Yıldırım on 9.10.23.
//

import UIKit
import MapKit
import CoreData

extension MKMapViewDelegate {
    
    func updatingTheMap(coordinate: CLLocationCoordinate2D?, fromDistance: CLLocationDistance, mapView: MKMapView) {

        let center = CLLocationCoordinate2D(latitude: coordinate?.latitude ?? 41.015137, longitude: coordinate?.longitude ?? 28.979530)
        mapView.setCenter(center, animated: false)
        
        let camera = MKMapCamera(lookingAtCenter: center, fromDistance: fromDistance, pitch: 0, heading: 0)
        mapView.setCamera(camera, animated: false)
        
    }
    
}
