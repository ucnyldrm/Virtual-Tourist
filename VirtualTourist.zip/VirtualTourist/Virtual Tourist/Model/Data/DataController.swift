//
//  DataController.swift
//  Virtual Tourist
//
//  Created by Can Yıldırım on 9.10.23.
//

import CoreData

class DataController {
    
    var persistentContainer: NSPersistentContainer
    
    var viewContext: NSManagedObjectContext {
        
        return persistentContainer.viewContext
        
    }
    
    init(modelName: String) {
        
        persistentContainer = NSPersistentContainer(name: modelName)
        
    }
    
    func load (completion: (() -> Void)? = nil) {
       
        persistentContainer.loadPersistentStores { storeDescription, error in
            
            guard error == nil else {
                
                fatalError(error!.localizedDescription)
    
            }
            
            self.persistentContainer.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
            
            completion?()
            
        }
    
    }
    
}
