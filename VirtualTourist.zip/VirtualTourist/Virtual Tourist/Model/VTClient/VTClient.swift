//
//  VTClient.swift
//  Virtual Tourist
//
//  Created by Can Yıldırım on 13.10.23.
//

import Foundation

class VTClient {
    
    
    static let apiKey = "c6216733207166594a60c38aa1204487"
    
    enum EndPoints {
        
        static let base = "https://www.flickr.com/services/rest/?method="
        static let apiKeyParam = "&api_key=\(VTClient.apiKey)"
        static let format = "&format=json&nojsoncallback=1"
        
        case photosForLocation(Double, Double, Int)
        case download(String, String, String)
        
        var url: URL {
            
            return URL(string: stringValue)!
            
        }
        
        var stringValue: String {
            
            switch self {
                
            case .photosForLocation(let lat, let lon, let page) : return EndPoints.base + "flickr.photos.search" + EndPoints.apiKeyParam + "&lat=\(lat)&lon=\(lon)&per_page=27&page=\(page)" + EndPoints.format
            case .download(let server, let id, let secret) : return "https://live.staticflickr.com/" + "\(server)/" + "\(id)_" + "\(secret)_b.jpg"
                
            }
            
        }
        
    }
    
    class func photosForLocation(latitude: Double, longitude: Double, page: Int?, completion: @escaping ([Picture], Error?) -> Void) {
        
        taskForGetRequest(url: EndPoints.photosForLocation(latitude, longitude, page ?? 1).url, responseType: Flickr.self) { response, error in
            
            if let response = response {
                
                completion(response.photos.photo, nil)
               
            } else {
                
                completion([], error)
            }

        }
    
    }
    
    class func download(server: String, id: String, secret: String, completion: @escaping (Data?, Error?) -> Void) {
        
        let task = URLSession.shared.dataTask(with: EndPoints.download(server, id, secret).url) { data, response, error in
            
            DispatchQueue.main.sync {
                
                completion(data, nil)
                
            }
     
        }
   
        task.resume()
        
    }
    
    class func taskForGetRequest<ResponseType: Decodable> (url: URL, responseType: ResponseType.Type, completion: @escaping (ResponseType?, Error?) -> Void) {
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            
            guard let data = data else {
                
                DispatchQueue.main.sync {
                    completion(nil, error)
                }
                return
            }
            
            let decoder = JSONDecoder()
            
            do {
                
                let response = try decoder.decode(ResponseType.self, from: data)
                DispatchQueue.main.sync {
                    completion(response, nil)

                }
                
            } catch {
                DispatchQueue.main.sync {
                    completion(nil, error)

                }
            }

        }
        
        task.resume()
        
    }

}
