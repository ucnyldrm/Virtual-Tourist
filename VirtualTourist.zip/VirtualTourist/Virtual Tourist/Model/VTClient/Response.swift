//
//  Response.swift
//  Virtual Tourist
//
//  Created by Can Yıldırım on 13.10.23.
//

import Foundation

struct Flickr: Codable {
    let photos: Photos
    let stat: String
}

struct Photos: Codable {
    let page, pages, perpage, total: Int
    let photo: [Picture]
}

struct Picture: Codable {
    let id, owner, secret, server: String
    let farm: Int
    let title: String
    let ispublic, isfriend, isfamily: Int
}
